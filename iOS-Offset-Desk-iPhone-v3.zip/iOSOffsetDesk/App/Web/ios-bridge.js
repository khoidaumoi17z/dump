/* Native iOS file/clipboard/export adapters; core.js is unchanged. */
(function(){
'use strict';
const handler=window.webkit?.messageHandlers?.iosDesk;
if(!handler)return;
let incoming=null;
function send(payload){handler.postMessage(payload);}
for(const [id,kind] of [['binary','binary'],['dump','dump']]){
 document.getElementById(id).onclick=()=>send({action:'pick',kind});
}
document.getElementById('diagnostics').onclick=()=>send({action:'diagnostics'});
document.getElementById('localFiles').onclick=()=>send({action:'localFiles'});
for(const id of ['reset','demo'])document.getElementById(id).addEventListener('click',()=>send({action:'reset'}));
function busy(value){for(const id of ['binary','dump','localFiles','reset','demo'])document.getElementById(id).disabled=!!value;window.setDumpBusy(!!value);}
// Replace the global download adapter used by all three exporters.
window.download=function(name,text,type){send({action:'export',name,text,type});};
document.getElementById('copy').onclick=()=>send({action:'copy',text:document.getElementById('out').value});
for(const link of document.querySelectorAll('a[href^="https://"]')){
 link.addEventListener('click',event=>{event.preventDefault();send({action:'openURL',url:link.href});});
}
window.OffsetIOS={
 begin(kind,name,size){
  if(!['binary','dump'].includes(kind)||!Number.isSafeInteger(size)||size<0)throw Error('Dữ liệu nhập không hợp lệ.');
  const limit=kind==='binary'?64*1024*1024:16*1024*1024;
  if(size>limit)throw Error('File vượt giới hạn của tool.');
  incoming={kind,name,size,bytes:new Uint8Array(size),position:0};
  report('Đang nhập '+name+'…');
 },
 append(base64){
  if(!incoming)throw Error('Chưa bắt đầu nhập file.');
  const chunk=atob(base64);
  if(incoming.position+chunk.length>incoming.size)throw Error('Dữ liệu vượt kích thước file.');
  for(let i=0;i<chunk.length;i++)incoming.bytes[incoming.position+i]=chunk.charCodeAt(i);
  incoming.position+=chunk.length;
  report('Đang nhập '+incoming.name+' · '+Math.floor(incoming.position/Math.max(1,incoming.size)*100)+'%');
 },
 finish(){
  if(!incoming||incoming.position!==incoming.size)throw Error('File nhập chưa đầy đủ.');
  const current=incoming;incoming=null;
  if(current.kind==='binary'){
   const next=OffsetDesk.parseMachO(current.bytes.buffer);
   model=next;sourceName=current.name;demoMode=false;
   document.getElementById('image').value=current.name;
  }else{
   const next=OffsetDesk.parseDump(new TextDecoder('utf-8').decode(current.bytes));
   if(!next.length)throw Error('Không thấy định nghĩa sub_HEX/FUN_HEX có thân hàm.');
   dumpRows=next;dumpName=current.name;demoMode=false;
  }
  rebuild();busy(false);
 },
 cancel(message){incoming=null;busy(false);report(message||'Đã hủy nhập file.');},
 notify(message){report(message);},
 setImportBusy(value){busy(value);},
 setDumpBusy(value){busy(value);}
};
})();
