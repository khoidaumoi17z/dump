# iOS Offset Desk v3 — bản sửa nhập tệp và giao diện

Đây là source code và workflow tạo IPA chưa ký. Chưa được build bằng Xcode hoặc kiểm thử trên iPhone trong môi trường hiện tại. Không thể cam kết mọi lỗi của thiết bị đã hết.

## Cài bản mới từ Windows hoặc iPhone
1. Upload `iOS-Offset-Desk-iPhone-v3.zip` vào thư mục gốc repo GitHub `ipaoffset`, giữ nguyên tên, không giải nén.
2. Thay nội dung `.github/workflows/build-ipa.yml` bằng file workflow kèm theo. Tên phải kết thúc đúng `.yml`, không có dấu chấm phía sau. Xóa workflow cũ trùng lặp nếu có.
3. Vào Actions → Build iOS Offset Desk v3 → Run workflow. Khi chạy thành công, tải artifact `iOS-Offset-Desk-v3-unsigned-IPA`, giải nén lấy IPA.
4. Ký và cài IPA bằng phương thức đã dùng trước đây. Mở app, kiểm tra tiêu đề **v3.0**. Source ZIP không phải IPA để cài trực tiếp.

## Nhập và dump
1. Bấm **Mở Mach-O iOS**, chọn file thực thi/thư viện đã giải nén từ IPA. File không bắt buộc có phần mở rộng.
2. Nếu file trong 3uTools không chọn được: mở ứng dụng Tệp, sao chép file sang **Trên iPhone → iOS Offset Desk**. Trong app bấm **Tệp trong ứng dụng → Mach-O → tên file**. Đặt file trực tiếp trong thư mục, không trong thư mục con.
3. Chờ thông báo nạp thành công và danh sách section xuất hiện. Chọn `__TEXT,__text` để dump mã ARM64; section dữ liệu có thể xuất HEX/BIN.
4. Để bắt đầu, đặt Bắt đầu = `0x0`, Số byte = `0x100` (nếu section đủ lớn), bấm Dump ARM64 .asm, rồi **Lưu vào Tệp** trong bảng chia sẻ. Để xuất toàn section, giữ độ dài tự điền.
5. Nếu có dump C do công cụ dịch ngược tạo ra, dùng **Mở dump C / SO.C**, hoặc Tệp trong ứng dụng → Dump C. ASM do app xuất không phải mã C và không nhập lại qua nút Dump C.
6. Nếu vẫn lỗi, bấm **Xuất nhật ký lỗi** và gửi file đó cùng ảnh lỗi. Nhật ký nằm trong Documents của app, không ghi nội dung binary; thông báo lỗi hệ thống có thể chứa đường dẫn file.

## “Image” là gì?
Nhãn đã đổi thành **Tên file thực thi / thư viện lúc chạy**. Không phải hình ảnh. Chỉ dùng để sinh mã hook, không cần điền để nhập hoặc dump. Nếu file được đổi tên sau khi lấy ra khỏi IPA, tên lúc chạy có thể khác tên file bạn nhập. Tool không tự xác minh tên đó.

## Các thay đổi
- Nút nhập native trực tiếp thay input HTML ẩn; picker sao chép tệp, hiển thị phần mở rộng và nhận các nhóm loại tệp tổng quát.
- Đường nhập nội bộ tránh phụ thuộc bộ lọc của nhà cung cấp Tệp bên ngoài.
- Sao chép có NSFileCoordinator, đọc ở tác vụ nền, truyền 64 KiB mỗi lượt thay 512 KiB.
- Giới hạn nhập 64 MiB Mach-O và 16 MiB dump C để giảm áp lực bộ nhớ; không còn quảng bá mức nhập 512 MiB trên iPhone.
- Chia 100 hàng/trang, lọc có trì hoãn ngắn, chọn hàng không dựng lại cả bảng. CSV/JSON vẫn xuất tất cả các mục nhận diện được.
- Khóa nhập/reset/demo khi tác vụ chạy; reset xóa snapshot native; tác vụ nhập cũ bị vô hiệu hóa sau khi WebContent đóng.
- Sửa inset giao diện; báo sự cố không tự kết luận thiếu bộ nhớ; thêm nhật ký.

## Giới hạn cần hiểu
- Dump là đọc byte file và disassemble ARM64, không dump bộ nhớ ứng dụng khác, không giải mã FairPlay, không tự dịch ngược ra C.
- Giải nén IPA trước khi chọn binary. Không nhập trực tiếp IPA/ZIP/APK/ELF Android.
- Phiên không được khôi phục tự động khi tiến trình giao diện đóng; nạp lại file để tiếp tục.
- Không có tính năng xác định offset “antiban” hay bảo đảm tránh phát hiện.
- Kiểm thử JavaScript bằng JSDOM và bộ dump C trên Linux không thay thế thử nghiệm UIKit/WebKit trên thiết bị thật.

Tham khảo API nhập tài liệu: https://developer.apple.com/documentation/uikit/uidocumentpickerviewcontroller
